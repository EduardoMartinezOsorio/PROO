#include <iostream>
void incrementar(int *valor) {
    (*valor)++;  
}

int main() {
    int num = 10;
    std::cout << "Valor antes: " << num << std::endl;  
    incrementar(&num);
    std::cout << "Valor despu�s: " << num << std::endl;  
    return 0;
}
