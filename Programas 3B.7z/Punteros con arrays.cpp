#include <iostream>
int main() {  
    int arreglo[] = {1, 2, 3, 4, 5};
    int *ptrArreglo = arreglo;  

    std::cout << "Primer elemento: " << *ptrArreglo << std::endl; 
    std::cout << "Segundo elemento: " << *(ptrArreglo + 1) << std::endl; 
    std::cout << "Tercer elemento: " << *(ptrArreglo + 2) << std::endl;

    
    for (int i = 0; i < 5; ++i) {
        std::cout << "Elemento " << i << ": " << *(ptrArreglo + i) << std::endl; 
    }
    return 0;
}
