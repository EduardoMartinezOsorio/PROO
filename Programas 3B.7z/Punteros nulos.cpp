#include <iostream>
int main() { 
    int *ptr = NULL; // Inicializaci�n con un puntero nulo
    if (ptr == NULL) {
        std::cout << "El puntero es nulo." << std::endl;
    } else {
        std::cout << "El valor apuntado por el puntero es: " << *ptr << std::endl;
    }
    return 0;
}
